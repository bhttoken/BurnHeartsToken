import React, {Component} from "react";
import Button from "@material-ui/core/Button";

class Whitepaper extends Component {
    render() {
        return(
            <div>
                <div class="whitepaper">
                    <Button class="button-33">
                    🤍 HEART BEAT </Button>
                    </div>
            </div>
        );
    }
}
export default Whitepaper;